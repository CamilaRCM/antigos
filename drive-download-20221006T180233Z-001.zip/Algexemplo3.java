/**
 * @(#)Algexemplo3.java
 *
 *
 * @author 
 * @version 1.00 2022/3/8
 */


public class Algexemplo3 {
public static void main (String[ ] args) {
		int n; n=10;
		double valor; valor = 20.3;
		
System.out.println (" o valor inteiro: " + n);
System.out.printf (" o valor real: %7.2f \n", valor);
}
}