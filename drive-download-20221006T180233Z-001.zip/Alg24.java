package AulasNewton.refactor;

import java.util.Scanner;

public class Alg24 {

	public static void main(String[] args) {
		
	int a,b,soma;
	
	Scanner ler = new Scanner(System.in);
	
	System.out.println( "Digite um numero para ser somado ");
	a=ler.nextInt();
	
	System.out.println( " Digite um novo numero para ser somado ");
	b=ler.nextInt();
	soma=a+b;
	
	if 
	(soma > 10)
		System.out.println(" Soma � " + soma  );
	

	}
}
