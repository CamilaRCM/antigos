public class Alg7{
public static void main (String[ ] args) {
		int a=30;
		int b=15;
		int subtracao = a-b;
		int multiplicacao = a*b;

System.out.println ("Numero1: " + a );
System.out.println ("Numero2: " + b );
System.out.println ("Resultado: " + a + " - " + b + " = "  + subtracao);
System.out.println ("Resultado: " + a + " * " + b + " = "  + multiplicacao);


}
}