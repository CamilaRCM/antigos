/**
 * @(#)Alg55.java
 *
 *
 * @author 
 * @version 1.00 2022/5/24
 */


public class Alg55 {

    public Alg55() {
    }
    
    
}