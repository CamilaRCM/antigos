import java.util.Scanner;
public class EX18 {
public static void main (String[ ] args) {

double salario;

Scanner Ler = new Scanner(System.in);

System.out.println("Digite seu sal�rio: ");
salario=Ler.nextInt();

if  (salario<500)
System.out.println (" Seu sal�rio reajustado ser�: ", salario*0.15);
else if
(salario>500) $$ (salario<1000)

}
}