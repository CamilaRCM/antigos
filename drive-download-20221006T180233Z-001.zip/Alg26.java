package AulasNewton.refactor;

import java.util.Scanner;

public class Alg26 {

	public static void main(String[] args) {

		String nomeProduto;
		double valor ;
		
		
		Scanner ler = new Scanner(System.in);

		System.out.println( "Digite o nome do produto");
		nomeProduto=ler.nextLine();	
		
		
		System.out.println( "Digite o valor do produto ");
		valor = ler.nextDouble();
		
if  (valor <= 100)
System.out.println (" valor de venda ser� ", valor*0.7);
else if
(valor>100) $$ (valor<=200)
System.out.println (" valor de venda ser� ", valor*0.5);

else 
System.out.println (" valor de venda ser� ", valor*0.5);

}
}
	
		
		
		
		
		
		
		
