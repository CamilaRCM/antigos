/**
 * @(#)Algexemplo2.java
 *
 *
 * @author 
 * @version 1.00 2022/3/8
 */


public class Algexemplo2 {
public static void main (String[ ] args) {
		int a; a=10;
		int b; b=20;
		int resultado; resultado = a+b;
		
System.out.println ("Numero: " + a );
System.out.println ("Numero: " + b );
System.out.println ("Numero: " + a + " +" + b + "="  + resultado);
}
}
